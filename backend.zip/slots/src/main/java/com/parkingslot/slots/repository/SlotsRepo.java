package com.parkingslot.slots.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.parkingslot.slots.model.ParkingSlots;

public interface SlotsRepo extends MongoRepository<ParkingSlots, Integer>{

}
