package com.parkingslot.slots.model;

import java.sql.Date;

import org.springframework.data.annotation.Id;

public class ParkingSlots {
	
	@Id
	private int slot_id;
	private String veh_id;
	private String owner;
	private String veh_type;
	private int duration;
	
	public ParkingSlots() {
		
	}
	
	public ParkingSlots(int slot_id, String veh_id, String owner, String veh_type, int duration) {
		super();
		this.slot_id = slot_id;
		this.veh_id = veh_id;
		this.owner = owner;
		this.veh_type = veh_type;
		this.duration = duration;
	}
	public int getSlot_id() {
		return slot_id;
	}
	public void setSlot_id(int slot_id) {
		this.slot_id = slot_id;
	}
	public String getVeh_id() {
		return veh_id;
	}
	public void setVeh_id(String veh_id) {
		this.veh_id = veh_id;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getVeh_type() {
		return veh_type;
	}
	public void setVeh_type(String veh_type) {
		this.veh_type = veh_type;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	
}
