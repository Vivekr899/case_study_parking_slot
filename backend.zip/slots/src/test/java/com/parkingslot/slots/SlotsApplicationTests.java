package com.parkingslot.slots;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlotsApplicationTests {

	@Test
	void contextLoads() {
	}

}
