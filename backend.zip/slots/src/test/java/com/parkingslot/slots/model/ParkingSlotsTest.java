package com.parkingslot.slots.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ParkingSlotsTest {

	ParkingSlots park = new ParkingSlots(22,"ka-0-000","aaa","2-wheeler",3);

	@Test
	void testGetSlot_id() {
		
		assertEquals(22,park.getSlot_id());
	}

	@Test
	void testSetSlot_id() {
		park.setSlot_id(2);
		assertEquals(2,park.getSlot_id());
	}

	@Test
	void testGetVeh_id() {
		String vehicle ="ka-0-000";
		String vehicle1 =park.getVeh_id();
		assertEquals(vehicle1,vehicle);
	}

	@Test
	void testSetVeh_id() {
		park.setVeh_id("ka-1-111");
		String vehicle ="ka-1-111";
		String vehicle1 =park.getVeh_id();
		assertEquals(vehicle1,vehicle);
	}

	@Test
	void testGetOwner() {
		String owner = "aaa";
		String owner1 = park.getOwner();
		assertEquals(owner1,owner);
	}

	@Test
	void testSetOwner() {
		park.setOwner("bbb");
		String owner = "bbb";
		String owner1 = park.getOwner();
		assertEquals(owner1,owner);
	}

	@Test
	void testGetVeh_type() {
		String vtype = "2-wheeler";
		String vtype1 = park.getVeh_type();
		assertEquals(vtype,vtype1);
	}

	@Test
	void testSetVeh_type() {
		park.setVeh_type("4-wheeler");
		String vtype = "4-wheeler";
		String vtype1 = park.getVeh_type();
		assertEquals(vtype,vtype1);
	}

	@Test
	void testGetDuration() {
		assertEquals(3,park.getDuration());
	}

	@Test
	void testSetDuration() {
		park.setDuration(5);
		assertEquals(5,park.getDuration());
	}

}
